tone_data <- data.frame(
  Tone = factor(rep(c("44", "21", "55", "31"), each = 6)),
  
  #####################################################

  Duration = c(0.34,0.41,0.36,0.43,0.38,0.37,  
               # 44（pan;pa;pai;pun;pu;pjen)#
               0.45,0.46,0.48,0.38,0.38,0.37,  
               # 21（pan;pan;pai;pun;pam;pam)#
               0.20,0.23,0.23,0.24,0.19,0.22,  
               # 55（ap;pjap;tot;kap;kat;tap)#
               0.26,0.24,0.19,0.21,0.22,0.25)  
               # 31（ap;pat;pik;pup;put;pjit)#
)


boxplot(Duration ~ Tone, data = tone_data,
        main = "Duration Distribution by Tone",
        xlab = "Tone Category", ylab = "Duration (s)")

cat("\n==== uncheck or check ====\n")
cat("\n44 vs 21:\n")
aov1 <- aov(Duration ~ Tone, data = tone_data[tone_data$Tone %in% c("44", "21"), ])
print(summary(aov1))

cat("\n55 vs 31:\n")
aov2 <- aov(Duration ~ Tone, data = tone_data[tone_data$Tone %in% c("55", "31"), ])
print(summary(aov2))

cat("\n==== uncheck vs check====\n")
cat("\n44 vs 55:\n")
aov3 <- aov(Duration ~ Tone, data = tone_data[tone_data$Tone %in% c("44", "55"), ])
print(summary(aov3))

cat("\n21 vs 31:\n")
aov4 <- aov(Duration ~ Tone, data = tone_data[tone_data$Tone %in% c("21", "31"), ])
print(summary(aov4))