clear;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
%%%%This program is written by the Laboratory of Language Sciences, Peking University%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%add syllable name here
[sig1,fs1]=audioread('mvau44.wav');%source syllable
[sig2,fs2]=audioread('mau35.wav');%target syllable

%add the steps you want to resythesis
steps=9;
continuum_switch=3;
%1:modify only phonation;2:modify only F0;3:modify both F0 and phonation
%switch the number here will get different type of the sppech tonal continuum

energy_switch=1;
framelength=128;
frameshift=32;
maxf0=300;
minf0=50;
lpc_order=20;
minEe=-0.005;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
sig1=resample(sig1,11025,fs1);
if exist('start_time1','var')
    start_time1=round(start_time1/fs1*11025);
    end_time1=round(end_time1/fs1*11025);
    start_time2=round(start_time2/fs2*11025);
    end_time2=round(end_time2/fs2*11025);
end
fs1=11025;
if fs1~=fs2
    sig2=resample(sig2,fs1,fs2);
    fs2=fs1;
end
fs=fs1;
sp1=sig1(:,1);
sp2=sig2(:,1);

if ~exist('start_time1','var')
    f01=MulticueF0v14(sp1,fs1,minf0,maxf0);
    f02=MulticueF0v14(sp2,fs2,minf0,maxf0);
    voiced1=find(f01~=0);
    voiced2=find(f02~=0);
    start_time1=round((voiced1(1)-30)/1000*fs1);
    end_time1=round((voiced1(end)+30)/1000*fs1);
    start_time2=round((voiced2(1)-30)/1000*fs2);
    end_time2=round((voiced2(end)+30)/1000*fs2);
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
frames1=enframe(sp1(start_time1:end_time1),framelength,frameshift);
frames2=enframe(sp2(start_time2:end_time2),framelength,frameshift);
framenum1=size(frames1,1);
framenum2=size(frames2,1);
times1=(start_time1+framelength/fs/2):(frameshift/fs):(start_time1+framelength/fs/2+(framenum1-1)*frameshift/fs);%每一帧对应的时刻
times1=(times1-start_time1)/(end_time1-start_time1);
times2=(start_time2+framelength/fs/2):(frameshift/fs):(start_time2+framelength/fs/2+(framenum2-1)*frameshift/fs);%每一帧对应的时刻
times2=(times2-start_time2)/(end_time2-start_time2);
frames1=frames1';
frames2=frames2';

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
lpc_coef1=zeros(lpc_order+1,framenum1);
err1=zeros(lpc_order+1,framenum1);
residue1=zeros(framelength,framenum1);
window_data=hamming(framelength);
Zi_inverse=zeros(lpc_order,1);
for i=1:framenum1
   %lpc analysis
   lpc_coef1(:,i)=lpc(filter([1 -0.98],1,frames1(:,i)).*window_data,lpc_order);
   %invers filtering
   residue1(:,i)=filter(lpc_coef1(:,i),1,frames1(:,i),Zi_inverse);
end
residue_signal1=sp1;
residue_signal1(start_time1:end_time1)=0;
for i=1:framenum1
    residue_signal1(start_time1+(i-1)*frameshift:start_time1+(i-1)*frameshift+framelength-1)=residue_signal1(start_time1+(i-1)*frameshift:start_time1+(i-1)*frameshift+framelength-1)+residue1(:,i).*window_data;
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
lpc_coef2=zeros(lpc_order+1,framenum2);
err2=zeros(lpc_order+1,framenum2);
residue2=zeros(framelength,framenum2);
window_data=hamming(framelength);
Zi_inverse=zeros(lpc_order,1);
for i=1:framenum2
   %lpc analysis
   lpc_coef2(:,i)=lpc(filter([1 -0.98],1,frames2(:,i)).*window_data,lpc_order);
   %invers filtering
   residue2(:,i)=filter(lpc_coef2(:,i),1,frames2(:,i),Zi_inverse);

end
residue_signal2=sp2;
residue_signal2(start_time2:end_time2)=0;
for i=1:framenum2
    residue_signal2(start_time2+(i-1)*frameshift:start_time2+(i-1)*frameshift+framelength-1)=residue_signal2(start_time2+(i-1)*frameshift:start_time2+(i-1)*frameshift+framelength-1)+residue2(:,i).*window_data;
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
f01=MulticueF0v14(residue_signal1,fs1,minf0,maxf0);
centre=((start_time1+end_time1)/2);
left=round(centre-1/f01(round(centre/fs1*1000))*fs1);
right=round(centre+1/f01(round(centre/fs1*1000))*fs1);
[~,pulsecentre1]=min(residue_signal1(left:right));
pulse1=pulsecentre1+left-1;
i=pulsecentre1+left-1;
while i>start_time1&&residue_signal1(i)<minEe
    period=round(i/fs1*1000);
    if f01(period)==0
        break;
    end
    left=round(i-1.5/f01(period)*fs1);
    right=round(i-0.5/f01(period)*fs1);
    [~,tmp]=min(residue_signal1(left:right));
    pulse1=[tmp+left-1,pulse1];
    i=tmp+left-1;
end
pulse1(1)=[];
i=pulse1(end);
while i<end_time1&&residue_signal1(i)<minEe
    period=round(i/fs1*1000);
    if f01(period)==0
        break;
    end
    left=round(i+0.5/f01(period)*fs1);
    right=round(i+1.5/f01(period)*fs1);
    [~,tmp]=min(residue_signal1(left:right));
    pulse1=[pulse1,tmp+left-1];
    i=tmp+left-1;
end
pulse1(end)=[];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
f02=MulticueF0v14(residue_signal2,fs2,minf0,maxf0);
centre=((start_time2+end_time2)/2);
left=round(centre-1/f02(round(centre/fs2*1000))*fs2);
right=round(centre+1/f02(round(centre/fs2*1000))*fs2);
[~,pulsecentre2]=min(residue_signal2(left:right));
pulse2=pulsecentre2+left-1;
i=pulsecentre2+left-1;
while i>start_time2&&residue_signal2(i)<minEe
    period=round(i/fs2*1000);
    if f02(period)==0
        break;
    end
    left=round(i-1.5/f02(period)*fs2);
    right=round(i-0.5/f02(period)*fs2);
    [~,tmp]=min(residue_signal2(left:right));
    pulse2=[tmp+left-1,pulse2];
    i=tmp+left-1;
end
pulse2(1)=[];
i=pulse2(end);
while i<end_time2&&residue_signal2(i)<minEe
    period=round(i/fs2*1000);
    if f02(period)==0
        break;
    end
    left=round(i+0.5/f02(period)*fs2);
    right=round(i+1.5/f02(period)*fs2);
    [~,tmp]=min(residue_signal2(left:right));
    pulse2=[pulse2,tmp+left-1];
    i=tmp+left-1;
end
pulse2(end)=[];

%%%%%%%%%%%%%%%%%%%%%%
tmp=find(f01>0);
for i=1:length(f01)
    if (i*fs1/1000>=start_time1)&&(i*fs1/1000<(start_time1+end_time1)/2)&&(f01(i)==0)%开头补点
        f01(i)=f01(tmp(1));
    elseif (i*fs1/1000<=end_time1)&&(i*fs1/1000>(start_time1+end_time1)/2)&&(f01(i)==0)%结尾补点
        f01(i)=f01(tmp(end));
    end
end
tmp=find(f02>0);
for i=1:length(f02)
    if (i*fs2/1000>=start_time2)&&(i*fs2/1000<(start_time2+end_time2)/2)&&(f02(i)==0)%开头补点
        f02(i)=f02(tmp(1));
    elseif (i*fs2/1000<=end_time2)&&(i*fs2/1000>(start_time2+end_time2)/2)&&(f02(i)==0)%结尾补点
        f02(i)=f02(tmp(end));
    end
end
tmp=f01;
tmp1=f01(round(start_time1/fs*1000):round(end_time1/fs*1000));
tmp2=f02(round(start_time2/fs*1000):round(end_time2/fs*1000));
tmp2=resample(tmp2,length(tmp1),length(tmp2));
tmp(round(start_time1/fs*1000):round(end_time1/fs*1000))=tmp2;
f0s=zeros(length(f01),steps);
for i=0:steps-1
    f0s(:,i+1)=f01+(tmp-f01)*i/(steps-1);
end

%%%%%%%%%%%%%%%%%%%%%

percentage1=(pulse1-start_time1)/(end_time1-start_time1+1);
percentage1=percentage1(1:end-1);
percentage2=(pulse2-start_time2)/(end_time2-start_time2+1);
percentage2=percentage2(1:end-1);
residue_signals=zeros(length(residue_signal1),steps);

switch continuum_switch
    case 1%modify only phonation
        tmp=residue_signal1;
        for i=1:length(percentage1)
            [~,j]=min(abs(percentage2-percentage1(i)));
            j=j(1);
            period1=residue_signal1(pulse1(i)+1:pulse1(i+1));
            period2=residue_signal2(pulse2(j)+1:pulse2(j+1));
            period2=resample(period2,length(period1),length(period2));
            if energy_switch==1
                period2=period2/max(abs(period2))*max(abs(period1));
            end
            tmp(pulse1(i)+1:pulse1(i+1))=period2;
        end

        for i=0:steps-1
            residue_signals(:,i+1)=residue_signal1+(tmp-residue_signal1)*i/(steps-1);
        end
    case 2 %modify only F0
        for k=1:steps
            residue_signals(:,k)=residue_signal1;
            residue_signals(pulse1(1):pulse1(end),k)=0;
            i=pulse1(1);
            while i<=pulse1(end)
                left=round(i/fs*1000);
                period=round(1/f0s(left,k)*fs);
                [~,j]=min(abs(pulse1(1:end-1)-i));
                tmp=residue_signal1(pulse1(j)+1:pulse1(j+1));
                tmp=resample(tmp,period,length(tmp));
                residue_signals(i+1:i+period,k)=tmp;
                i=i+period;
            end
        end
    case 3 %modify both F0 and phonation
        for k=1:steps
            residue_signals(:,k)=residue_signal1;
            residue_signals(pulse1(1):pulse1(end),k)=0;
            i=pulse1(1);
            while i<=pulse1(end)
                left=round(i/fs*1000);
                period=round(1/f0s(left,k)*fs);
                pctg=(i-start_time1)/(end_time1-start_time1+1);
                [~,j]=min(abs(percentage1(1:end-1)-pctg));
                tmp1=residue_signal1(pulse1(j)+1:pulse1(j+1));
                [~,j]=min(abs(percentage2(1:end-1)-pctg));
                tmp2=residue_signal2(pulse2(j)+1:pulse2(j+1));
                tmp1=resample(tmp1,period,length(tmp1));
                tmp2=resample(tmp2,period,length(tmp2));
                if energy_switch==1
                    tmp2=tmp2/max(abs(tmp2))*max(abs(tmp1));
                end
                tmp=tmp1+(tmp2-tmp1)*(k-1)/(steps-1);
                residue_signals(i+1:i+period,k)=tmp;
                i=i+period;
            end
        end
end

%%%%%%%%%%%%%%%%%%%%%%
output=residue_signals;
output(start_time1:end_time1,:)=0;
for k=1:steps
    frames3=enframe(residue_signals(start_time1:end_time1,k),framelength,frameshift);
    frames3=frames3';
    for i=1:size(frames3,2)
        tmp=filter(1,lpc_coef1(:,i),frames3(:,i),Zi_inverse);
        output((i-1)*frameshift+start_time1:(i-1)*frameshift+start_time1+framelength-1,k)=output((i-1)*frameshift+start_time1:(i-1)*frameshift+start_time1+framelength-1,k)+tmp.*window_data;
    end
    output(:,k)=output(:,k)/mean(abs(output(:,k)))*mean(abs(sp1));
end

audiowrite('output.wav',reshape(output,size(output,1)*steps,1),fs1);