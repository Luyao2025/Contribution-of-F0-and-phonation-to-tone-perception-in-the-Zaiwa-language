################################################################################
### This file shows all code for plots and statistical tests in Chapter3.6,  ###
### except the turkey test, which runs in SPSS and given in another file.    ###
### The end of this file also shows how to calculate the data used in SPSS.  ###
################################################################################
setwd("C:/Users/Administrator/Desktop/code and data")
options(warn = -1)
library(openxlsx)
library(readxl)
library(ggplot2)
library(knitr)
library(gridExtra)
library(knitr)
library(dplyr)
library(car)
library(multcomp)
library(reshape2)
library(cowplot)

# 1. data preparing ########################################
data_1 <- read_excel('identification experiment data.xlsx') 
colnames(data_1)
data_2 <- read_excel('discrimination experiment data.xlsx')
colnames(data_2)

# Delete null
data_1 <- data_1[complete.cases(data_1),]
unique(data_1$Answer)
data_2 <- data_2[complete.cases(data_2),]
unique(data_2$IsCorrect)

# tagging
data_1$Answer <- ifelse(data_1$Answer == "mau", 1, 0)
data_2$IsCorrect <- ifelse(data_2$IsCorrect == "YES", 1, 0)


## 1.1 calculate the identification rate and discrimination accuracy  ############################################
# the identification rate
grouped_identify <- data_1 %>%
  group_by(Group, StimulusType) %>%
  summarise(p_mau = mean(Answer == 1))

grouped_identify$p_mvau <- 1 - grouped_identify$p_mau
colnames(grouped_identify) <- c('Group', "StimulusType", 'p_mau', 'p_mvau')

# the discrimination accuracy
grouped_clarify <- data_2 %>%
  group_by(Group, StimulusMedian) %>%
  summarise(pro_right = mean(IsCorrect == 1))
colnames(grouped_clarify) <- c('Group', "StimulusType", 'pro_right')

# put them together
grouped_summ <-
  merge(grouped_identify,
        grouped_clarify,
        by = c('Group', 'StimulusType'),
        all = TRUE)



## 1.2 plot Figure 8: Results of the categorical perception experiments ############################################
# name for every group 
houzhui <- c(":modal 35-44",
             ":modal-pressed 35",
             ":modal 35-pressed 44",
             ":pressed 35-44",
             ":modal-pressed 44",
             ":pressed 44-modal 35")
values = c("#2878B5", "#9AC9D8", "#999999", "#C82423")
p <- list()
for (i in 1:6) {
  temp <- grouped_summ[grouped_summ$Group == i,]
  colnames(temp)
  temp$p_mau <- 100 * temp$p_mau
  temp$p_mvau <- 100 * temp$p_mvau
  temp$pro_right <- 100 * temp$pro_right
  colnames(temp) = c("序号", "StimulusType", "Identification rate of /mau35/", "Identification rate of /mau44/", "Discrimination rate")
  data = melt(
    temp,
    id.vars = c('StimulusType'),
    measure.vars = c("Identification rate of /mau35/", "Identification rate of /mau44/", "Discrimination rate"),
    variable.name = 'da',
    value.name = 'value'
  )

  p[[i]] <-
    ggplot(data = data, aes(
      x = StimulusType,
      y = value,
      group = da,
      shape = da,
      color = da        
    )) +
    geom_point(size = 2) +
    geom_line(size = 1) +
    theme_bw() + 
    labs(
      # i=1
      title = paste0('Group', i, houzhui[i]),
      x = 'Stimulus number',
      y = ''
    ) +
    theme(
      panel.grid.major = element_line(colour = NA),
      panel.background = element_rect(fill = "transparent", colour = NA),
      plot.background = element_rect(fill = "transparent", colour = NA),
      panel.grid.minor = element_blank(),
      text = element_text(family = "STXihei"),
      legend.title = element_blank(),
      legend.position = c(0.15, 0.65)
    ) +
    scale_x_continuous(breaks = 1:9, labels = 1:9,limits = c(1, 9)) +
    scale_y_continuous(breaks = seq(0, 100, by = 20),
                       labels = seq(0, 100, by = 20),limits = c(0, 100)) +
    scale_color_manual(values = c(
      "Identification rate of /mau35/" = "#2878B5",  
      "Identification rate of /mau44/" = "#C82423",  
      "Discrimination rate" = "#999999"            
    )) +
    theme(
      axis.title.x = element_text(size = 14), 
      axis.text.x = element_text(size = 14),  
      axis.text.y = element_text(size = 14),  
      legend.text = element_text(size = 14)   
    )+
    theme(
      panel.border = element_rect(color = "black", size = 1), 
      axis.line = element_line(color = "black", size = 1)     
    )
  
}

for (i in 1:6) {
  p[[i]] <- p[[i]] + theme(legend.position = "none")
}

legend <- get_legend(
  ggplot(data = data, aes(
    x = StimulusType,
    y = value,
    group = da,
    color = da,
    shape = da
  )) +
    geom_point() +
    geom_line() +
    scale_color_manual(values = c(
      "Identification rate of /mau35/" = "#2878B5",  
      "Identification rate of /mau44/" = "#C82423",  
      "Discrimination rate" = "#999999"             
    ))+
    labs(color = NULL, shape = NULL) +   
    guides(shape = "none") +  
    theme(legend.position = "bottom")+
    theme(
      legend.position = "bottom",
      legend.text = element_text(size = 12),  
      legend.title = element_blank(),         
      legend.spacing.x = unit(1, "lines")      
    )
)

combined_plot <- plot_grid(
  plot_grid(p[[1]], p[[2]], p[[3]], p[[4]], p[[5]], p[[6]], nrow = 2, ncol = 3),
  legend,
  ncol = 1,
  rel_heights = c(1, 0.1) 
)

# show the plot
print(combined_plot)

# save the plot 
ggsave(filename = "plot/Figure8.png", plot = combined_plot, width = 12, height = 9, dpi = 300)

# 2. identification rate analysis  ############################################################
# Select the four groups to analyze later
data_part <- data_1[data_1$Group %in% c(1, 3, 4, 6), ]

## 2.1 calculate the identification rate and Descriptive statistics of the data ############################################
grouped_part_mean <- data_part %>%
  group_by(Group, StimulusType) %>%
  summarise(p_identify = mean(Answer == 1))

grouped_part <- data_part %>%
  group_by(Group, StimulusType, SubjectCode) %>%
  summarise(p_identify_i = mean(Answer == 1))

grouped_part_sd <- grouped_part %>%
  group_by(Group, StimulusType) %>%
  summarise(sd = sd(p_identify_i), count = n())

part_summ <-
  merge(grouped_part_mean, grouped_part_sd, by = c('Group', 'StimulusType'))

part_summ$se <- part_summ$sd / sqrt(part_summ$count)

# add a new column for plotting shape for different group
part_summ$shape <- ifelse(part_summ$Group == 1, 19,
                          ifelse(part_summ$Group == 3, 23,
                                 ifelse(part_summ$Group == 4, 15, 17)))  
part_summ$Group <- paste0("Group",part_summ$Group)

## 2.2 Plot Figure 9: Identification curves of the four continua ####
group_labels <- c("Group1" = "Group1:modal 35-44", 
                  "Group3" = "Group3:modal 35-pressed 44", 
                  "Group4" = "Group4:pressed 35-44", 
                  "Group6" = "Group6:pressed 44-modal 35")

Figure9 <- ggplot(part_summ, aes(
    x = StimulusType,
    y = 100*(1 - p_identify),
    color = as.character(Group)
  )) +
    geom_line(size = 1) +
    scale_color_manual(values = c("#2878B5", "#9AC9D8", "#999999", "#C82423"),
                       labels  = group_labels) +
    labs(x = "Stimulus number", y = "Identification rate of /mau35/") +
    geom_point(aes(x = StimulusType, y = 100*(1 - p_identify)), size = 4, fill = "white") +
    geom_errorbar(
      aes(
        x = StimulusType,
        ymin = 100*(1 - p_identify - se),
        ymax = 100*(1 - p_identify + se)
      ),
      width = 0.2,
      size = 2
    ) +
    scale_x_continuous(breaks = 1:9, labels = 1:9) +
    scale_y_continuous(breaks = seq(0, 100, by = 20),
                       labels = seq(0, 100, by = 20)) +
    scale_shape_manual(values = c(19, 23, 22, 24), guide = "none") +
    theme_bw() +
    theme(panel.grid = element_blank()) +
    theme(
      legend.title = element_blank(),
      panel.border = element_rect(color = "black", fill = NA, linewidth = 1),
      legend.position = c(0.2, 0.89),
      legend.background = element_rect(fill = "white", colour = "black", size = 0.5)
    )+
    theme(
      axis.title.x = element_text(size = 14), 
      axis.title.y = element_text(size = 14), 
      axis.text.x = element_text(size = 14),  
      axis.text.y = element_text(size = 14), 
      legend.text = element_text(size = 14)   
    )
Figure9

ggsave(filename = "plot/Figure9.png", plot = Figure9, width = 10, height = 7, dpi = 300)

## 2.3 calculate the identification boundaries and the boundary widths  ############################################

### 2.3.1 for every group in total ############################################
split_data <- split(data_part, data_part$Group)

models <- lapply(split_data, function(df) {
  model <- glm(Answer ~ StimulusType , data = df, family = binomial) 
  return(model)
})

key_result <-
  data.frame(matrix(ncol = 5, nrow = length(models)))
colnames(key_result) <-
  c("group", "bondary", "x_low", "x_up", "width")
group_num <- c(1, 3, 4, 6)
for (i in 1:length(models)) {
  key_result$group[i] <- group_num[i]
  key_result$bondary[i] <-
    -models[[i]]$coefficients[1] / models[[i]]$coefficients[2]
  key_result$x_low[i] <-
    (log(0.25 / (1 - 0.25)) - models[[i]]$coefficients[1]) / models[[i]]$coefficients[2]
  key_result$x_up[i] <-
    (log(0.75 / (1 - 0.75)) - models[[i]]$coefficients[1]) / models[[i]]$coefficients[2]
  key_result$width[i] <-
    abs(key_result$x_up[i] - key_result$x_low[i])
  cat("/n")
}

# print the result
kable(key_result, digits = 2)


### 2.3.2 for every single subject ############################################

glm_part <- data_part %>%
  group_by(Group, SubjectCode) %>%
  do(model = glm(Answer ~ StimulusType   , data = ., family = binomial)) 

glm_result_part <-
  data.frame(matrix(ncol = 6, nrow = dim(glm_part)[1]))
colnames(glm_result_part) <-
  c("Group", "SubjectCode", "b0_constant", "b0_coefficient", "bondary", "width")
for (i in 1:(dim(glm_part)[1])) {
  group <- glm_part[i, 1]
  name <- glm_part[i, 2]
  temp_result <-
    glm_part[i, 3][[1]][[1]]$coefficients
  b0 <- temp_result[1]
  b1 <- temp_result[2]
  bondary <- -b0 / b1
  x_low <- (log(0.25 / (1 - 0.25)) - b0) / b1
  x_up <- (log(0.75 / (1 - 0.75)) - b0) / b1
  width <-
    abs(x_up - x_low) 
  glm_result_part[i, ] <-
    c(group, name, b0, b1, bondary, width)
  
}

bondary_all <- glm_result_part[, c(1, 2, 5)]
width_all <- glm_result_part[, c(1, 2, 6)]


## 2.4 Pairwise comparison of identification boundaries and boundary width differences ############################################
### 2.4.1 Comparing group 1 with group 4 ############################################
## the identification boundaries
bondary_all_14 <-
  bondary_all[bondary_all$Group %in% c(1, 4), ]
anova_bondary_14 <-
  aov(bondary ~ Group, bondary_all_14)
summary(anova_bondary_14)

# t.test(bondary ~ Group, data = bondary_all_14)  # we can also check the result by t test

## the boundary widths
width_all_14 <-
  width_all[width_all$Group %in% c(1, 4), ]
anova_width_14 <- aov(width ~ Group, width_all_14)
summary(anova_width_14)
# t.test(width ~ Group, data = width_all_14)  

### 2.4.2 Comparing group 3 with group 6 ############################################
## the identification boundaries
bondary_all_36 <-
  bondary_all[bondary_all$Group %in% c(3, 6), ]
anova_bondary_36 <-
  aov(bondary ~ Group, bondary_all_36)
summary(anova_bondary_36)
# t.test(bondary ~ Group, data = bondary_all_36) # we can also check the result by t test

## the boundary widths
width_all_36 <-
  width_all[width_all$Group %in% c(3, 6), ]
anova_width_36 <- aov(width ~ Group, width_all_36)
summary(anova_width_36)
# t.test(width ~ Group, data = width_all_36)  

### 2.4.3 comparing group14 with grpup36 ############################################
# Aggregate group 1 and group 4, aggregate group 3 and group 6, 
# and compare the differences in boundary width between these two new groups.
temp14 <- width_all_14 %>%
  mutate(Group = 1)
temp36 <- width_all_36 %>%
  mutate(Group = 2)
temp_width <- rbind(temp14, temp36)
anova_width_2_bondary <- aov(width ~ Group, temp_width)
summary(anova_width_2_bondary)
t.test(width ~ Group, data = temp_width)


## 2.5 Plot Figure 10:Identification boundary widths of the four continua ############################################
par(mfrow = c(1, 1))
group_labels <- c("1" = "Group1:modal 35-44", 
                  "3" = "Group3:modal 35-pressed 44", 
                  "4" = "Group4:pressed 35-44", 
                  "6" = "Group6:pressed 44-modal 35")

violin_colors <- c("#2878B5", "#9AC9D8", "#999999", "#C82423") 

Figure10 <- ggplot(width_all, aes(x = as.factor(Group), y = width, fill = as.factor(Group))) +
  geom_violin(width = 0.6, alpha = 0.7) +         
  geom_boxplot(width = 0.1, fill = "white", color = "black", outlier.shape = NA) + 
  ylim(0, 10) +
  labs(
    # title = "Violin and Boxplots of Boundary Widths within Each Group",
    x = "Group",
    y = "Width"
  ) +
  scale_fill_manual(values = violin_colors,
                    breaks = c("1", "3", "4", "6"),  
                    labels = group_labels) +         
  theme_minimal() +
  theme(
    # legend.position = "none",                         
    legend.position = c(0.8,0.86),                         
    legend.title = element_blank(),
    legend.text = element_text(size = 14) ,         
    legend.box.background = element_rect(color = "black", size = 0.5), 
    panel.border = element_rect(color = "black", fill = NA, size = 1),  
    axis.title.x = element_text(size = 14),           
    axis.title.y = element_text(size = 14),        
    axis.text.x = element_text(size = 14),           
    axis.text.y = element_text(size = 14)          
  )

print(Figure10)
ggsave(filename = "plot/Figure10.png", plot = Figure10, width = 9, height = 6, dpi = 300)

# 3. discrimination rate analysis ###############################################
data_part2 <- data_2[data_2$Group %in% c(1, 3, 4, 6), ]

## 3.1 calculate the discrimination rates and its statistics ####
grouped_clarify_part_mean <- data_part2 %>%
  group_by(Group, StimulusMedian) %>%
  summarise(pro_right = mean(IsCorrect == 1))
colnames(grouped_clarify_part_mean) <-
  c('Group', "StimulusMedian", 'pro_right')

grouped_part2 <- data_part2 %>%
  group_by(Group, StimulusMedian, SubjectCode) %>%
  summarise(pro_right = mean(IsCorrect == 1))

grouped_part_sd2 <- grouped_part2 %>%
  group_by(Group, StimulusMedian) %>%
  summarise(sd = sd(pro_right), count = n())

part_summ2 <-
  merge(grouped_clarify_part_mean, grouped_part_sd2, by = c('Group', 'StimulusMedian'))

part_summ2$se <- part_summ2$sd / sqrt(part_summ2$count)
colnames(part_summ2)

part_summ2$Group <- paste0("Group",part_summ2$Group)

## 3.2 plot Figure 11 Discrimination curves of the four continua ####
group_labels <- c("Group1" = "Group1:modal 35-44", 
                  "Group3" = "Group3:modal 35-pressed 44", 
                  "Group4" = "Group4:pressed 35-44", 
                  "Group6" = "Group6:pressed 44-modal 35")
Figure11 <- ggplot(part_summ2, aes(
    x = StimulusMedian,
    y = 100*(pro_right),
    color = as.character(Group)
  )) +
    geom_line(size = 1) +
    scale_color_manual(values = c("#2878B5", "#9AC9D8", "#999999", "#C82423"),
                       labels = group_labels) +
    labs(x = "Stimulus number", y = "Discrimination rate") +
    geom_point(aes(x = StimulusMedian, y = 100*(pro_right)), size = 4, fill = "white") +
    geom_errorbar(
      aes(
        x = StimulusMedian,
        ymin = 100*(pro_right - se),
        ymax = 100*(pro_right + se)
      ),
      width = 0.2,
      size = 2
    ) +
    scale_x_continuous(breaks = 1:9, labels = 1:9) +
    scale_y_continuous(breaks = seq(0, 100, by = 20),
                       labels = seq(0, 100, by = 20)) +
    scale_shape_manual(values = c(19, 23, 22, 24), guide = "none") +
    theme_bw() +
    theme(panel.grid = element_blank()) +
    theme(
      legend.title = element_blank(),
      panel.border = element_rect(color = "black", fill = NA, linewidth = 1),
      legend.position = c(0.2, 0.89),
      legend.background = element_rect(fill = "white", colour = "black", size = 0.5)
    ) + 
    coord_cartesian(xlim = c(1, 9), ylim = c(0, 100))+
    theme(
      axis.title.x = element_text(size = 14), 
      axis.title.y = element_text(size = 14),
      axis.text.x = element_text(size = 14), 
      axis.text.y = element_text(size = 14),  
      legend.text = element_text(size = 14) )  
Figure11
ggsave(filename = "plot/Figure11.png", plot = Figure11, width = 9, height = 7, dpi = 300)


# Calculate The discrimination rate per person per stimulus type (2-8) for each group.
# then use the data for following analysis in SPSS to identify the peak 
grouped_clarify_indivi <- data_part2 %>%
  group_by(Group, StimulusMedian, SubjectCode) %>%
  summarise(pro_right = mean(IsCorrect == 1))
# save the data used in SPSS
write.xlsx(grouped_clarify_indivi, 'discrimination rate of each subject for each stimulus.xlsx')

